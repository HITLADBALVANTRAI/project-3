import turtle

for i in range(2):
    turtle.shape("")#Write the shape as square
    turtle.pencolor("")#Write the pen color as red
    turtle.forward(200)
    turtle.left(90)
    
for i in range(2):
    turtle.shape("")#Write the shape as circle
    turtle.pencolor("")#Write the pen color as green
    turtle.forward(200)
    turtle.left(90)
